# Whatsapp-Bot-
**What this bot does**
This bot automates whatsapp and will download and send the youtube and whatsapp video.


**How to USE?**

Supported Commands:

1️⃣➡️  ytmp4 URL
2️⃣➡️  ytmp3 URL
3️⃣➡️  fb URL
4️⃣➡️  help

Contact Mazan👦 for more details 🇵🇰♥️

**How to install**

Install node js and npm on your system/server.

Step 1:  git clone https://github.com/MazanLabeeb/whatsmazan
Step 2:  cd whatsmazan
Step 3: npm install
Step 4: node index.js

Scan the QR code and boom the bot is working.

⚠️⚠️
You have to download the chrome browser in your machine. 
If you have previously downloaded, set the path of the browser in the index.js file
puppeteer: {
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  }
⚠️⚠️

This script uses whatsapp-web.js which is made using Puppeteer. 


*How to install Google Chrome on Ubuntu*

wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt install ./google-chrome-stable_current_amd64.deb

